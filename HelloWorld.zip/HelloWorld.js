let user = "Steven";
console.log(user+"\n Hello to the World of programming! ");
